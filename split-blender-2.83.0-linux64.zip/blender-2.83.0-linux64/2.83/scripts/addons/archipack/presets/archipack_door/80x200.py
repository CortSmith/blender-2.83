import bpy
d = bpy.context.active_object.data.archipack_door[0]

d.handle = 'BOTH'
d.panels_distrib = 'REGULAR'
d.direction = 0
d.frame_y = 0.029999999329447746
d.door_y = 0.019999999552965164
d.flip = False
d.panels_y = 1
d.frame_x = 0.10000000149011612
d.model = 0
d.door_offset = 0.0
d.x = 0.800000011920929
d.z = 2.0
d.hole_margin = 0.10000000149011612
d.panel_border = 0.20000000298023224
d.panels_x = 1
d.panel_spacing = 0.10000000149011612
d.chanfer = 0.004999999888241291
d.panel_bottom = 0.0
d.n_panels = 1
d.y = 0.20000000298023224
